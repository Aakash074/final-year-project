
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'aakash074',
  applicationName: 'microserverless',
  appUid: 'wkcgXbb9sytv19kBHH',
  orgUid: '88b90266-9f69-44ee-8599-b5648af52429',
  deploymentUid: '20713b41-4188-4351-bfce-7cdea7002051',
  serviceName: 'todoslsfw',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'todoslsfw-dev-deleteTodo', timeout: 6 };

try {
  const userHandler = require('./todo/deleteTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}